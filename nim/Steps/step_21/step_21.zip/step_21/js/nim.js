document.body.onclick = function (event) {
  event.target.classList.add("removed")
}